import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_sms/flutter_sms.dart';
//import 'package:google_fonts/google_fonts.dart';

class inicio extends StatefulWidget {
  @override
  _pantallainicio createState() => _pantallainicio();
}

class _pantallainicio extends State<inicio> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(
        title: Text(
          'Conoce acerca de Nosotros',
          style: TextStyle(fontSize: 30),
        ),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(
                margin: EdgeInsets.all(.25),
                child: Column(children: <Widget>[
                  Container(
                    child: Image.network(
                        "https://plazalindavista.mx/wp-content/uploads/2020/09/Casa-to%C3%B1o.png"),
                  ),
                  Container(
                      margin: EdgeInsets.all(5.0),
                      child: Text(
                        "Fue en 1985 cuando de la calle pasaron a instalarse al garage de la casa familiar, ubicada en Floresta No. 77, Colonia Clavería en Azcapotzalco, en donde ya venderían comida diariamente. Un cliente asiduo sugirió que le cambiaran de nombre al local y así nació La Casa de Toño. El pozole y las flautas ya eran los platillos estrellas y Toño comenzó a abrir otras sucursales como las de Santa María La Ribera y Marina Nacional ",
                        textAlign: TextAlign.justify,
                        style: TextStyle(fontSize: 22),
                      )),
                  Container(
                    child: Text("\n"),
                  ),
                  Container(
                    child: Image.network(
                        "https://m.lacasadetono.com.mx/wp-content/uploads/2019/07/Enfrijoladas.png"),
                  ),
                  Container(
                    child: Text("\n"),
                  ),
                  Container(
                    child: Text("\n"),
                  ),
                  Container(
                    child: Text("\n"),
                  ),
                  Container(
                    child: Image.network(
                        "https://www.elfinanciero.com.mx/resizer/g8JdhugKpOhdMDoUnR2ZJCA7dnI=/1200x630/cloudfront-us-east-1.images.arcpublishing.com/elfinanciero/NNKSR4B5NLBMTNVKCH3YKW2TBE.jpg"),
                  )
                ])),
          ],
        ),
      ),
      backgroundColor: Colors.lightGreenAccent.shade100,
    ));
  }
}
