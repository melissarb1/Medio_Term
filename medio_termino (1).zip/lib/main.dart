import 'package:flutter/material.dart';
import 'tabsabajo.dart';

void main() {
  runApp(tabsabajo());
}
