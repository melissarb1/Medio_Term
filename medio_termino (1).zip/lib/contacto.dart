import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_sms/flutter_sms.dart';

class contacto extends StatefulWidget {
  @override
  _pantallacontacto createState() => _pantallacontacto();
}

class _pantallacontacto extends State<contacto> {
  openwhatsapp(String message, String destinatario) async {
    var whatsapp = destinatario;
    var whatsappURl_android =
        "whatsapp://send?phone=" + whatsapp + "&text=" + message;
    var whatappURL_ios = "https://wa.me/$whatsapp?text=${Uri.parse(message)}";
    if (Platform.isIOS) {
      // for iOS phone only
      if (await canLaunch(whatappURL_ios)) {
        await launch(whatappURL_ios, forceSafariVC: false);
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: new Text("Error whatsapp")));
      }
    } else {
      // android , web
      if (await canLaunch(whatsappURl_android)) {
        await launch(whatsappURl_android);
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: new Text("Error whatsapp")));
      }
    }
  }

  hacerllamda() async {
    const url = 'tel: +525547594408';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'error al llamar la $url';
    }
  }

  enviarsms(String msj, List<String> d) async {
    String r = await sendSMS(message: msj, recipients: d).catchError((onError) {
      print(onError);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            'Contacto',
            style: TextStyle(fontSize: 30),
          ),
          backgroundColor: Colors.green,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                margin: EdgeInsets.all(.25),
                width: 200,
                child: TextButton(
                    child: Text(
                      'SMS',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.green.shade900),
                    onPressed: () {
                      String msj = "demo";
                      List<String> d = ["+525547594408"];
                      enviarsms(msj, d);
                    }),
              ),
               Container(
                    child: Text("\n"),
                  ),
              Container(
                margin: EdgeInsets.all(.25),
                width: 200,
                child: TextButton(
                  child: Text(
                    'Llamada',
                    style: TextStyle(fontSize: 25, color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                      primary: Colors.green.shade900),
                  onPressed: hacerllamda,
                ),
              ),
              Container(
                    child: Text("\n"),
                  ),
              Container(
                margin: EdgeInsets.all(.25),
                width: 200,
                child: TextButton(
                    child: Text(
                      'WhatsApp',
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.green.shade900),
                    onPressed: () {
                      String msj = "demo";
                      String d = "+525547594408";
                      openwhatsapp(msj, d);
                    }),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.lightGreenAccent.shade100,
      ),
    );
  }
}
