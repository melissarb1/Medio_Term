import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class acerca extends StatefulWidget {
  @override
  String url = "https://m.lacasadetono.com.mx/";
  _acercaState createState() => _acercaState();
}

class _acercaState extends State<acerca> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(
              title: Text(
                'Sitio Web',
                style: TextStyle(fontSize: 30),
              ),
              backgroundColor: Colors.green,
            ),
            body: WebView(
              initialUrl: widget.url,
            )));
  }
}
