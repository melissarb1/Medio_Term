import 'package:flutter/material.dart';
import 'obtenerdatos.dart';

class pantalla extends StatefulWidget {
  @override
  _pantallaState createState() => _pantallaState();
}

class _pantallaState extends State<pantalla> {
  TextEditingController num1controller = new TextEditingController();
  String id =
      "https://foodish-api.herokuapp.com/images/samosa/samosa19.jpg";
  String r = "";
  Future<void> dato() async {
    obtenerdatos dat = obtenerdatos();
    r = await dat.getdatos();
    setState(() {
      id = r;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(
        title: Text(
          'Nuestro Menu',
          style: TextStyle(fontSize: 30),
        ),
        backgroundColor: Colors.green,
      ),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            width: 600,
            height: 400,
            child: Image.network(id),
          ),
          Container(
            child: Text("\n"),
          ),
          Container(
            margin: EdgeInsets.all(.25),
            width: 200,
            child: TextButton(
                child: Text(
                  'Mostrar Menu',
                  style: TextStyle(fontSize: 25, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                    primary: Colors.green.shade900),
                onPressed: () {
                  dato();
                }),
          ),
        ],
      )),
      backgroundColor: Colors.lightGreen.shade100,
    ));
  }
}
