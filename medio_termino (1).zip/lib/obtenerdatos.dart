import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class obtenerdatos {
  Future<String> getapi() async {
    String myurl = "https://foodish-api.herokuapp.com/api/";
    final response = await http.get(Uri.parse(myurl));
    return response.body.toString();
  }

  Future<String> getdatos() async {
    String myregreso = "";
    myregreso = await getapi();
    Map<String, dynamic> data = jsonDecode(myregreso);
    String r = data['image'];
    print(r);
    return r;
  }
}
