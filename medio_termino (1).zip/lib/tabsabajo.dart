import 'package:flutter/material.dart';
import 'pantalla.dart';

import 'inicio.dart';
import 'contacto.dart';
import 'acerca.dart';
import 'pantalla.dart';

class tabsabajo extends StatefulWidget {
  @override
  _tabsabajoState createState() => _tabsabajoState();
}

class _tabsabajoState extends State<tabsabajo> {
  @override
  int mi_indice = 0;
  final pantallas = <Widget>[inicio(), contacto(), acerca(), pantalla()];
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: IndexedStack(
          index: mi_indice,
          children: pantallas,
        ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.green,
          selectedItemColor: Colors.lightGreenAccent,
          iconSize: 40,
          currentIndex: mi_indice,
          onTap: (index) => setState(() => mi_indice = index),
          items: [
            new BottomNavigationBarItem(
              icon: Icon(Icons.info),
              label: 'Conocenos',
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.contact_mail),
                label: 'Contacto'),
            BottomNavigationBarItem(icon: Icon(Icons.open_in_browser), label: 'Nuestro Sitio'),
            BottomNavigationBarItem(
                icon: Icon(Icons.image_outlined), label: 'Platillos')
          ],
        ),
      ),
    );
  }
}
