package com.example.medio_termino

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
